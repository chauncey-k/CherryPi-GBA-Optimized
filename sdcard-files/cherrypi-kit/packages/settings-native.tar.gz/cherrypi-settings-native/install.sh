#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STATE=/root/cherrypi-settings-native/state
[ "$(id -u)" -eq 0 ] || exit 1
pidof gpsp >/dev/null 2>&1 && { echo 'Exit gpSP and recover serial login before installing'; exit 1; }
grep -qxF 'ttyS0::respawn:/usr/local/sbin/cherrypi-autostart' /etc/inittab || { echo 'Install the previous autostart package first'; exit 1; }
[ -x /usr/local/sbin/cherrypi-autostart ] && [ -x /root/audio-tools/amixer ] || exit 1
[ -r /etc/cherrypi-autostart.conf ] && [ -x /root/gpsp/gpsp ] || exit 1
(cd "$BASE" && sha256sum -c SHA256SUMS)
sh -n "$BASE/supervisor.sh"
sh -n "$BASE/device-control.sh"
mkdir -p "$STATE"
if [ ! -f "$STATE/backup-complete" ]; then
    cp -p /root/gpsp/gpsp "$STATE/gpsp"
    cp -p /usr/local/sbin/cherrypi-autostart "$STATE/supervisor.sh"
    if [ -f /usr/local/sbin/cherrypi-device-control ]; then
        cp -p /usr/local/sbin/cherrypi-device-control "$STATE/device-control.sh"
    else
        touch "$STATE/no-previous-device-control"
    fi
    touch "$STATE/backup-complete"
fi
cp "$BASE/gpsp" /root/gpsp/gpsp.device-new
chmod 755 /root/gpsp/gpsp.device-new
cp "$BASE/supervisor.sh" /usr/local/sbin/cherrypi-autostart.device-new
chmod 755 /usr/local/sbin/cherrypi-autostart.device-new
cp "$BASE/device-control.sh" /usr/local/sbin/cherrypi-device-control.device-new
chmod 755 /usr/local/sbin/cherrypi-device-control.device-new
mv /usr/local/sbin/cherrypi-device-control.device-new /usr/local/sbin/cherrypi-device-control
mv /usr/local/sbin/cherrypi-autostart.device-new /usr/local/sbin/cherrypi-autostart
mv /root/gpsp/gpsp.device-new /root/gpsp/gpsp
sync
echo 'Installed native settings and menu direction repeat. Remove recovery marker and reboot.'
