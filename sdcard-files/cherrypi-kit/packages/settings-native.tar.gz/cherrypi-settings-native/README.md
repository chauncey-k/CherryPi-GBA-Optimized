# Cherry Pi 原生设备设置与菜单长按连调

日期：2026-10-14。

## 本次定位证据

用户已反馈：背光明暗立即变化，但 Brightness 百分比需要重进菜单才变化；保存出现 Settings save failed。
板上 gpSP 和设备脚本的 SHA256 与刷新包一致，排除了新旧文件混装。当前配置包含 VOLUME=45，却没有 BRIGHTNESS；日志没有设备脚本输出。此前代码只把 system 返回值转换为成功/失败，未记录错误码，因此不能认定旧外部调用失败的具体系统原因。

声音与亮度的处理路径不同：音量左右键只修改菜单变量；亮度每个左右键都调用外部脚本。之前只调整绘图路径，没有消除外部调用依赖。
方向键源码只处理真实按下/松开，不实现菜单连发，且忽略内核重复事件，所以按住只调一档是独立的已确认问题。

## 本版改动

- gpSP 直接写 backlight sysfs，并回读实际档位；不启动子进程进行亮度预览。
- gpSP 通过 ALSA 控制 ioctl 设置 Headphone Playback Volume/Switch，不再从菜单启动 amixer。
- 配置由 gpSP 直接写临时文件、同步、原子替换；保留 ROMDIR 和其他配置，去除音量/亮度重复键。
- 关机请求由 gpSP 创建运行时标记，正常退出后仍由监督脚本执行关机。菜单内不再调用 system。
- 方向键按下立即响应，按住约350ms后每120ms重复；松开即停止，确认和关机按键不连发。游戏中的方向按下/松开逻辑不变。
- 具体错误显示在菜单并写入 /tmp/cherrypi-autostart.log，例如 ALSA open error 2、Config save error 30。

当前背光驱动为10个非零档位，因此每个短按仍是10%一档；按住可连续调整多档，不能把显示档位百分比当作线性视觉亮度。

保持现有内核、DTB、驱动、游戏、BIOS和运行库。所有原生音频设置字段按当前实际内核的 Headphone 控件定义实现，仍需实机确认。

## 安装

先用串口 Ctrl+C 恢复登录，root 登录后执行 sync、poweroff，等关机完成再断电取卡。
将 cherrypi-settings-native-20261014.tar.gz 复制到 GAMES 根目录，并创建空文件 DISABLE_GBA_AUTOSTART（无扩展名）。安全弹出卡，插回上电后登录 root：

```sh
mkdir -p /mnt/games
grep -qs ' /mnt/games ' /proc/mounts || mount -t vfat /dev/mmcblk0p3 /mnt/games
gzip -dc /mnt/games/cherrypi-settings-native-20261014.tar.gz | tar -xf - -C /root
cd /root/cherrypi-settings-native
sha256sum -c SHA256SUMS
```

全部 OK 后安装：

```sh
sh /root/cherrypi-settings-native/install.sh
```

看到 Installed 后：

```sh
rm -f /mnt/games/DISABLE_GBA_AUTOSTART
sync
reboot
```

安装前不能有 gpsp 正在运行，脚本会拒绝替换运行中的二进制。

## 实机验收

1. 开机列表按 Menu，选择 Brightness。轻按左右应立即改变明暗和百分比。
2. 按住左或右一秒以上，应连续变多个档位，松开停止；最低1、最高max，不环绕。
3. 按 A 保存，不应出现 Settings save failed；返回并再次进入，数值一致。
4. 选择 Volume，调整并保存；回到游戏确认音量改变。
5. 正常重启，检查音量和亮度恢复。
6. 检查取消关机、正常退出回列表；关机首次用串口确认系统完成停止后再拔电源。

若仍出现错误，不要盲目重烧系统。拍下菜单的具体错误文字，恢复登录后执行：

```sh
tail -n 80 /tmp/cherrypi-autostart.log
cat /etc/cherrypi-autostart.conf
```

错误30一般对应只读文件系统，错误2一般对应缺少文件或设备，错误13一般对应权限；以完整操作名称与日志定位。

## 回退

原版文件保存在 /root/cherrypi-settings-native/state。使用 GAMES/DISABLE_GBA_AUTOSTART 恢复登录后执行：

```sh
sh /root/cherrypi-settings-native/uninstall.sh
rm -f /mnt/games/DISABLE_GBA_AUTOSTART
sync
reboot
```

恢复本次安装前的 gpSP 和监督/控制脚本，不删除配置、ROM或存档。

## 验证与源码

已完成 ARMv5 软件浮点交叉编译。主机临时目录测试覆盖：原生背光写入/禁止0、ALSA ioctl 参数、配置原子替换/保留其他键、ALSA失败诊断、只读保存失败诊断、关机请求、菜单百分比逐帧更新、长按延时/重复/松键停止/会话重置，以及安装回退和启动恢复。声卡使用模拟 ioctl，不作为真实硬件已验证的结论。

完整GPL源码在 source/gpsp，新增原生控制在 cherrypi/settings.c；build.sh 使用原 WSL Buildroot 工具链。补丁记录相对上一版的修改。
