#!/bin/sh
set -eu
STATE=/root/cherrypi-settings-native/state
[ "$(id -u)" -eq 0 ] || exit 1
pidof gpsp >/dev/null 2>&1 && { echo 'Exit gpSP before rollback'; exit 1; }
[ -f "$STATE/backup-complete" ] || { echo 'Backup missing'; exit 1; }
cp -p "$STATE/gpsp" /root/gpsp/gpsp.rollback
cp -p "$STATE/supervisor.sh" /usr/local/sbin/cherrypi-autostart.rollback
mv /root/gpsp/gpsp.rollback /root/gpsp/gpsp
mv /usr/local/sbin/cherrypi-autostart.rollback /usr/local/sbin/cherrypi-autostart
if [ -f "$STATE/no-previous-device-control" ]; then
    rm -f /usr/local/sbin/cherrypi-device-control
else
    cp -p "$STATE/device-control.sh" /usr/local/sbin/cherrypi-device-control
fi
sync
echo 'Previous gpSP and autostart restored. Remove recovery marker and reboot.'
