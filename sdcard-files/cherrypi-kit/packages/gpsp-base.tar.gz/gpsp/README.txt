Cherry Pi gpSP prototype, 2026-10-09
Upstream: https://github.com/Apaczer/gpsp branch miyoo
Commit: 4f8c8378041663ca1d3da4413bbf36d0c8a70cd6
Target: ARMv5TE soft-float musl, Cherry Pi Linux 5.4.196, fb0 480x272.
Run ./run-gpsp.sh --platform-test first. Q or Ctrl+C exits.
For games: provide your own genuine 16384-byte gba_bios.bin here,
then ./run-gpsp.sh /absolute/path/to/game.gba
WASD directions; J A; K B; U L; I R; Enter Start; Space Select;
M menu; Q exit. Menus: WASD navigate, J/Enter confirm, K back.
Serial keypresses automatically release after 180 ms without repeats.
Audio is dummy/silent. This is an initial hardware-validation build.
The 320x240 UI is centered within 480x272; aspect game image is
approximately 320x213, with black borders. Full-panel scaling is pending.
No BIOS or games are included. Actual-board performance is not yet tested.
