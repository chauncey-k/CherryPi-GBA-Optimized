# Cherry Pi 开机自动进入游戏列表

日期：2026-10-14。

## 行为与范围

沿用现有 Linux、DTB、gpSP 二进制和实体 GPIO 按键，不重新烧录系统。
BusyBox init 启动监督脚本，占用 ttyS0 作为 gpSP 标准输入；不需要电脑连接，也不需要登录。正常退出 gpSP 后约一秒重新打开游戏列表。
自动挂载 GAMES、设置 DAC 音频通路并恢复 Headphone 65% 音量。游戏文件默认位于 GAMES/roms，目录不存在时使用 GAMES 根目录。

当前是复用 gpSP 文件选择器的原型，并非新增独立桌面。已完成主机模拟验证；真实板子上的自动启动和实体按键仍需按下列流程验证。

## 安装前提

当前系统能手动运行 gpSP，已安装 /root/audio-tools，实体按键已经能操作游戏列表。
内核必须识别名为 cherrypi-gamepad 的输入设备；否则安装脚本拒绝修改启动配置。
仅支持已有单条 ttyS0 getty 配置的 BusyBox 系统。不会自动安装或更换按键驱动。

## 一次安装

1. 退出游戏，在串口执行 sync、poweroff，等关机完成后断电取卡。
2. 将 cherrypi-autostart-20261014.tar.gz 复制到 SD 卡的 GAMES 根目录，安全弹出。
3. 插卡上电，用原来的 root 账户登录，执行：

```sh
mkdir -p /mnt/games
grep -qs ' /mnt/games ' /proc/mounts || mount -t vfat /dev/mmcblk0p3 /mnt/games
gzip -dc /mnt/games/cherrypi-autostart-20261014.tar.gz | tar -xf - -C /root
cd /root/cherrypi-autostart
sha256sum -c SHA256SUMS
```

仅在全部显示 OK 后继续：

```sh
sh /root/cherrypi-autostart/install.sh
```

确认输出 Installed 后再重启：

```sh
sync
reboot
```

不用手工重新加载 init。安装不会切断当前会话。启动监督脚本需要 init 分配终端，不要在已有 gpSP 运行时另开一个监督实例。

## 日常操作

上电后直接显示游戏文件列表，用实体方向键移动，A 或 Start 确认。
游戏中按实体 Menu 键打开菜单，选择 Exit gpSP，确认后退出；监督脚本重新启动 gpSP，返回游戏列表。
菜单中的 Return to game 是继续当前游戏，不是回到列表；Load new game 可以直接换游戏。
串口 Q 也可退出并返回列表。首次测试保留电脑串口观察异常；之后可以断开电脑，仅使用板子正常供电。

## 音量

/etc/cherrypi-autostart.conf 中 VOLUME=65 控制开机恢复的音量，ROMDIR 控制列表起始目录。
需要串口维护时使用下节的恢复方法。修改配置后重启生效。百分比对应音量寄存器，并非线性听感响度。

## 不用串口也能恢复

正常关机取卡，在电脑上于 GAMES 根目录新建空文件：

```text
DISABLE_GBA_AUTOSTART
```

注意文件名没有 .txt 后缀。安全弹出，插卡上电后恢复串口登录。
此文件存在时每次启动都跳过 gpSP。删除它后，下次重启恢复自动启动。

无法正常关机时直接断电会有文件系统风险；恢复标记只是避免自动启动锁住调试入口，并非断电保护。

## 串口维护与卸载

串口 Ctrl+C 可使监督脚本暂停本次启动并恢复登录；若终端未发送中断，用 SD 卡恢复标记。
恢复登录后可查看：

```sh
cat /tmp/cherrypi-autostart.log
cat /tmp/cherrypi-autostart.log.previous
cat /etc/cherrypi-autostart.conf
```

暂停标记位于 /run/cherrypi-autostart.paused，正常重启清除。永久软件禁用也可使用 /root/.disable-gba-autostart。

卸载开机自动启动：

```sh
sh /root/cherrypi-autostart/uninstall.sh
sync
reboot
```

卸载只把本包的 ttyS0 启动项恢复为备份的原 getty 项，保留其他 inittab 修改；保留配置和安装文件以便再次安装。
本包未实现实体电源键关机。要安全关机，先恢复串口登录，再执行 sync、poweroff。独立产品的关机菜单属于后续工作。

## 故障保护与已验证内容

缺少 GAMES、GPIO gamepad、BIOS、音频工具或游戏文件时退回串口登录。
连续三次异常退出或不足三秒的退出后退回登录，避免持续重启。正常游戏退出后自动重新打开列表。
日志位于 tmpfs，仅保留当前及上一轮日志，避免持续写 SD 卡。

已在主机临时目录、伪终端和模拟 gpSP 下验证：正常退出重新打开、连续失败保护、SD 卡恢复标记、缺按键保护、重复安装、卸载保留无关配置。未将模拟结果作为实际上板验证。
