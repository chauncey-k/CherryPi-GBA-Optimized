#!/bin/sh
set -eu
STATE=/root/cherrypi-autostart/state
ENTRY='ttyS0::respawn:/usr/local/sbin/cherrypi-autostart'
[ "$(id -u)" -eq 0 ] || { echo 'Run as root'; exit 1; }
[ -s "$STATE/original-serial-entry" ] || { echo 'Serial entry backup missing'; exit 1; }
TMP=/etc/inittab.gba-new.$$
trap 'rm -f "$TMP"' EXIT
original=$(cat "$STATE/original-serial-entry")
awk -v entry="$ENTRY" -v original="$original" '$0 == entry { print original; next } { print }' /etc/inittab > "$TMP"
chmod 644 "$TMP"
mv "$TMP" /etc/inittab
sync
echo 'Serial login restored for next boot. Run sync then reboot.'
