#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STATE=/root/cherrypi-autostart/state
ENTRY='ttyS0::respawn:/usr/local/sbin/cherrypi-autostart'
[ "$(id -u)" -eq 0 ] || { echo 'Run as root'; exit 1; }
[ -x /root/gpsp/run-gpsp.sh ] && [ -x /root/gpsp/gpsp ] || { echo 'gpSP not installed'; exit 1; }
grep -q 'Name="cherrypi-gamepad"' /proc/bus/input/devices || { echo 'GPIO gamepad not detected; installation cancelled'; exit 1; }
[ -x /root/audio-tools/amixer ] && [ -x /root/audio-tools/audio-mode ] || { echo 'Audio tools missing'; exit 1; }
[ -r /etc/inittab ] || { echo 'BusyBox inittab missing'; exit 1; }
if ! grep -qxF "$ENTRY" /etc/inittab; then
    count=$(grep -c '^ttyS0::respawn:' /etc/inittab || :)
    [ "$count" -eq 1 ] || { echo 'Expected exactly one ttyS0 respawn entry; installation cancelled'; exit 1; }
    grep '^ttyS0::respawn:' /etc/inittab | grep -q '/sbin/getty' || { echo 'Unexpected serial entry; installation cancelled'; exit 1; }
fi
mkdir -p "$STATE" /usr/local/sbin
if ! grep -qxF "$ENTRY" /etc/inittab; then
    grep '^ttyS0::respawn:' /etc/inittab > "$STATE/original-serial-entry"
    cp -p /etc/inittab "$STATE/inittab.before-install"
fi
[ -s "$STATE/original-serial-entry" ] || { echo 'Original serial entry backup missing'; exit 1; }
cp "$BASE/supervisor.sh" /usr/local/sbin/cherrypi-autostart
chmod 755 /usr/local/sbin/cherrypi-autostart
if [ ! -f /etc/cherrypi-autostart.conf ]; then
    cp "$BASE/config" /etc/cherrypi-autostart.conf
fi
sh -n /usr/local/sbin/cherrypi-autostart
TMP=/etc/inittab.gba-new.$$
trap 'rm -f "$TMP"' EXIT
awk -v entry="$ENTRY" '/^ttyS0::respawn:/ { print entry; next } { print }' /etc/inittab > "$TMP"
chmod 644 "$TMP"
mv "$TMP" /etc/inittab
sync
echo 'Installed. No kernel, DTB or gpSP binary changed.'
echo 'Use sync then reboot when ready. Installation does not change this session.'
echo 'Recovery: create DISABLE_GBA_AUTOSTART on GAMES, then reboot.'
