# Cherry Pi 音频工具（2026-10-11）

## 当前状态
实机确认 F1C100s Audio Codec、播放 PCM、/dev/dsp、/dev/mixer 已创建。
当前 gpSP 启动脚本仍 export SDL_AUDIODRIVER=dummy；没有 amixer；尚未连接耳机或功放/音箱。
音频初始化日志不能证明实际发声。game config missing 是游戏专用兼容性配置未匹配，和声卡无关，源码加载时不把该返回值作为退出条件。
本包不替换内核、gpSP 或 SDL，也不自动启用声音。

## 安装一次
退出游戏，sync、poweroff。关机后在电脑把 audio-tools-20261011.tar.gz 复制到 GAMES 根目录，安全弹出。
板子上电登录后：
```sh
mkdir -p /mnt/games
grep -qs ' /mnt/games ' /proc/mounts || mount -t vfat /dev/mmcblk0p3 /mnt/games
gzip -dc /mnt/games/audio-tools-20261011.tar.gz | tar -xf - -C /root
cd /root/audio-tools
sha256sum -c SHA256SUMS
/root/audio-tools/amixer -c 0 scontrols
/root/audio-tools/amixer -c 0 scontents
```

把 scontrols 和 scontents 输出提供给助手，核对具体控制项后再调路由和音量。
BusyBox tar 不支持 -z，必须使用 gzip 管道方式。
工具使用包内 libasound 与 ALSA 配置，不覆盖系统库。可以直接 /root/audio-tools/amixer 调用，不必安装到 /usr/bin。

## 接音频设备之后
已核对本板 U1 为 PAM8301 功放；OUT+/OUT- 是功放输出，可接一只 8Ω 2W 扬声器，两端均不接地。无需额外功放。详见 docs/audio/CherryPi-最低成本扬声器接法.md。此前把这些引脚当作普通模拟输出的说明已更正。
音量与播放通路就绪后，可先用包内 test-tone.wav 做短音频测试：
```sh
/root/audio-tools/aplay -D hw:0,0 /root/audio-tools/test-tone.wav
```

这是 48kHz、16bit、双声道、2秒、440Hz 小幅度测试音。并不自动打开静音开关；幅度小不代表功放输出音量已安全设置。首次使用从低音量开始。
退出 gpSP 后切换真实音频后端：
```sh
/root/audio-tools/audio-mode dsp
gba
```

脚本只修改 run-gpsp.sh 中 SDL_AUDIODRIVER 一行。下一次启动 gpSP 生效，不需要重启。
恢复静音：
```sh
/root/audio-tools/audio-mode dummy
```

查看当前后端：
```sh
/root/audio-tools/audio-mode status
```

## 验证与限制
工具使用原有 Buildroot/Bootlin ARMv5 soft-float 工具链构建，检查 ELF 动态依赖、打包校验和 shell 语法。
尚未在实机运行工具或确认发声。
已有模拟帧率不足的改版游戏可能出现音频变慢或断续；音频启用不会提高游戏模拟性能。
