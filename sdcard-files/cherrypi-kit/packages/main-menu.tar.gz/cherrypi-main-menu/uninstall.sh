#!/bin/sh
set -eu
STATE=/root/cherrypi-main-menu/state
[ "$(id -u)" -eq 0 ] || exit 1
pidof gpsp cherrypi-launcher >/dev/null 2>&1 && { echo 'Recover serial login before rollback'; exit 1; }
[ -f "$STATE/backup-complete" ] || { echo 'No backup found'; exit 1; }
cp -p "$STATE/supervisor.sh" /usr/local/sbin/cherrypi-autostart.rollback
mv /usr/local/sbin/cherrypi-autostart.rollback /usr/local/sbin/cherrypi-autostart
if [ -f "$STATE/no-previous-launcher" ]; then
    rm -f /usr/local/bin/cherrypi-launcher
else
    cp -p "$STATE/cherrypi-launcher" /usr/local/bin/cherrypi-launcher.rollback
    mv /usr/local/bin/cherrypi-launcher.rollback /usr/local/bin/cherrypi-launcher
fi
sync
echo 'Previous launcher restored. Remove recovery marker and reboot.'
