#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
STATE=/root/cherrypi-main-menu/state
[ "$(id -u)" -eq 0 ] || exit 1
if pidof gpsp cherrypi-launcher >/dev/null 2>&1; then
    echo 'Recover serial login before installing (DISABLE_GBA_AUTOSTART on GAMES).'; exit 1
fi
grep -qxF 'ttyS0::respawn:/usr/local/sbin/cherrypi-autostart' /etc/inittab || { echo 'Existing autostart installation required'; exit 1; }
[ -x /usr/local/sbin/cherrypi-autostart ] && [ -x /root/gpsp/run-gpsp.sh ] && [ -x /root/gpsp/gpsp ] || exit 1
[ -r /etc/cherrypi-autostart.conf ] && [ -x /usr/local/sbin/cherrypi-device-control ] || exit 1
(cd "$BASE" && sha256sum -c SHA256SUMS)
sh -n "$BASE/supervisor.sh"
mkdir -p "$STATE" /usr/local/bin
if [ ! -f "$STATE/backup-complete" ]; then
    cp -p /usr/local/sbin/cherrypi-autostart "$STATE/supervisor.sh"
    if [ -f /usr/local/bin/cherrypi-launcher ]; then
        cp -p /usr/local/bin/cherrypi-launcher "$STATE/cherrypi-launcher"
    else
        touch "$STATE/no-previous-launcher"
    fi
    touch "$STATE/backup-complete"
fi
cp "$BASE/cherrypi-launcher" /usr/local/bin/cherrypi-launcher.new
chmod 755 /usr/local/bin/cherrypi-launcher.new
cp "$BASE/supervisor.sh" /usr/local/sbin/cherrypi-autostart.new
chmod 755 /usr/local/sbin/cherrypi-autostart.new
mv /usr/local/bin/cherrypi-launcher.new /usr/local/bin/cherrypi-launcher
mv /usr/local/sbin/cherrypi-autostart.new /usr/local/sbin/cherrypi-autostart
sync
echo 'Installed. Remove DISABLE_GBA_AUTOSTART and reboot.'
