# Cherry Pi 独立主菜单

基于已经在板上验证的 Linux、GPIO 按键、音频、背光和 gpSP 原生设置版本。

## 本版行为

- 上电进入主菜单：Games、Recent games、Settings、Power off。
- Games 按文件名排序，递归扫描 ROMDIR，支持 .gba、.zip、.bin。最多2048个文件、8层子目录；压缩包内容是否可玩由现有 gpSP 决定。
- 最近游戏保留10条，重启后保留；删除的文件自动从列表过滤。
- Settings 可以预览音量、亮度。A/Start 保存并返回；B 取消，恢复进入设置前的数值。
- 方向键短按调一档，长按约350ms后每120ms连续调节；确认键不连发。
- 选择游戏时主菜单释放 framebuffer、输入设备和串口，再用 exec 启动现有 gpSP。退出游戏后监护脚本重新启动主菜单。
- Power off 默认选 Cancel。确认关机后同步文件并执行 Linux poweroff。
- 游戏失败后返回主菜单显示提示；主菜单连续失败三次恢复串口登录。

按键：方向键移动，A 或 Start 确认，B 返回，Menu 进入设置。游戏内仍使用原 gpSP 菜单退出游戏。

当前界面使用现有英文位图字体。中文文件名显示为问号，实际文件路径仍保留，不影响传给 gpSP 的路径。需要清楚区分游戏时先用英文文件名；中文字体支持留待下一版。

## 安装到板子

安装包：cherrypi-main-menu-20261014.tar.gz。

这是安装到目前已能自动启动 gpSP、设置已正常工作的系统的增量包，不是重新烧录镜像。

1. 先退出游戏。通过串口 Ctrl+C 恢复登录，root 登录后执行 sync、poweroff。等系统停止后断电取卡。
2. 用读卡器打开 GAMES 分区，将安装包复制到根目录，并创建空文件 DISABLE_GBA_AUTOSTART（无扩展名）。安全弹出后插回板子上电，串口登录 root。
3. 执行以下命令。安装脚本会校验文件、备份已有监护脚本，并拒绝在 gpsp 或主菜单仍运行时安装。

```sh
mkdir -p /mnt/games
grep -qs ' /mnt/games ' /proc/mounts || mount -t vfat /dev/mmcblk0p3 /mnt/games
gzip -dc /mnt/games/cherrypi-main-menu-20261014.tar.gz | tar -xf - -C /root
sh /root/cherrypi-main-menu/install.sh
```

看到 Installed 后：

```sh
rm -f /mnt/games/DISABLE_GBA_AUTOSTART
sync
reboot
```

重启后可以断开电脑，使用实体按键。默认 ROM 目录 /mnt/games/roms，沿用 /etc/cherrypi-autostart.conf 中的 ROMDIR；最近记录 /root/.cherrypi-recent。

## 实板验收

1. 不接电脑上电，进入四项主菜单。
2. Games 选择一个以前可玩的游戏，退出后返回主菜单；Recent games 中出现这个游戏。
3. Settings 轻按、长按左右，亮度数值和明暗立即变化；A 保存、B 取消分别检查。音量可以进入游戏听声音验证。
4. 重启检查设置及最近游戏保留。
5. Power off 先取消一次，再确认关机。第一次通过串口确认系统已停止；本板是否能自动切断供电取决于硬件，菜单关机不等于断开电源。

## 出错和回退

恢复登录：断电前先正常关机；在 GAMES 根目录创建 DISABLE_GBA_AUTOSTART，重新上电。也可以串口 Ctrl+C 中断主菜单。

```sh
tail -n 80 /tmp/cherrypi-autostart.log
tail -n 80 /tmp/cherrypi-autostart.log.previous
cat /etc/cherrypi-autostart.conf
sha256sum /usr/local/bin/cherrypi-launcher
```

回退到这次安装前的游戏列表：

```sh
sh /root/cherrypi-main-menu/uninstall.sh
rm -f /mnt/games/DISABLE_GBA_AUTOSTART
sync
reboot
```

备份位于 /root/cherrypi-main-menu/state，多次安装不会覆盖首次备份。回退保留音量/亮度配置、游戏、存档和最近记录。

## 实现和验证范围

新增原生主菜单程序 /usr/local/bin/cherrypi-launcher，更新监护脚本 /usr/local/sbin/cherrypi-autostart。使用现有 /root/gpsp/lib/SDL 和 /root/gpsp/run-gpsp.sh，不更换内核、DTB、驱动或 gpSP 二进制。

音量通过 ALSA 控制 ioctl 预览，亮度直接写 sysfs；保存复用已验证的原生设置实现，采用临时文件、fsync、原子替换。预览不启动 shell，也不在每次按键时保存配置。

已完成 ARMv5TEJ EABI 软件浮点交叉编译及运行库依赖检查。主机模拟测试覆盖文件排序/历史上限/去重、带空格及特殊字符路径的 exec 参数、设置实时预览/边界/取消/保存失败、真实事件循环中的长按、关机确认、游戏退出和异常返回、连续主菜单失败恢复、SD 恢复标记、安装校验和回退。

这些是主机模拟验证；还未将本包安装到用户板卡，实际屏幕、按键和游戏行为需按上面的清单验收。

完整 GPL-2.0-or-later 源码和许可随包提供。板上源码目录 /root/cherrypi-main-menu/source，测试 /root/cherrypi-main-menu/tests；build.sh 在 WSL 使用 /home/a/work/cherrypi/build/rootfs/host 工具链，可通过 CHERRYPI_WORKSPACE 覆盖其工程根目录。