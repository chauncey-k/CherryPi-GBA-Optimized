#!/usr/bin/env bash
set -euo pipefail
BASE=$(cd "$(dirname "$0")" && pwd)
HOST=${CHERRYPI_WORKSPACE:-/home/a/work/cherrypi}/build/rootfs/host
CC="$HOST/bin/arm-linux-gcc"
SYSROOT=$("$CC" --print-sysroot)
export PKG_CONFIG_SYSROOT_DIR="$SYSROOT"
export PKG_CONFIG_LIBDIR="$SYSROOT/usr/lib/pkgconfig"
mkdir -p "$BASE/build"
"$CC" -O2 -Wall -Wextra -march=armv5te -mtune=arm926ej-s -mfloat-abi=soft \
    $("$HOST/bin/pkg-config" --cflags sdl) \
    "$BASE/source/launcher.c" "$BASE/source/library.c" "$BASE/source/platform.c" "$BASE/source/settings.c" \
    $("$HOST/bin/pkg-config" --libs sdl) -Wl,-rpath,/root/gpsp/lib \
    -o "$BASE/build/cherrypi-launcher"
OUTPUT="$BASE/cherrypi-main-menu"
[ ! -f "$BASE/install.sh" ] || OUTPUT="$BASE"
cp "$BASE/build/cherrypi-launcher" "$OUTPUT/cherrypi-launcher"
"$HOST/bin/arm-linux-strip" "$OUTPUT/cherrypi-launcher"
